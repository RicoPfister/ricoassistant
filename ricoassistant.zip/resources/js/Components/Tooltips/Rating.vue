<template>

    <div class="absolute bg-gray-200 top-0 left-0 mt-12 border border-black p-3 text-left font-normal">
        <b>Quality Scale:</b><br>
        <br>
        <b>Untragbar. Rückgabe:</b><br>
        00-10 Schwerer Defekt<br>
        11-20 Fehlkonstruktion<br>
        21-30 Schwere Täuschung<br>
        <br>

        <b>Vertretbar, wenn Nutzen erfüllt:</b><br>
        31-40 Leichter Defekt<br>
        41-50 Leichte Täuschung<br>
        51-60 Spührbare Mängel<br>
        61-70 Unbedeutende Mängel<br>
        <br>

        <b>Zufrieden:</b><br>
        71-80 Qualität gut<br>
        81-90 Qualität hochwertig<br>
        91-99 Nahezu perfekt<br>
    </div>

</template>

<script setup>

import { ref, onMounted, computed  } from 'vue';



</script>
